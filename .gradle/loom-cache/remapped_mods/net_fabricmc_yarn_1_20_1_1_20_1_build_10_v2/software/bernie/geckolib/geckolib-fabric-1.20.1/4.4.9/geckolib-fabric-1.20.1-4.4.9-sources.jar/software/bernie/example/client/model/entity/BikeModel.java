package software.bernie.example.client.model.entity;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import software.bernie.example.client.renderer.entity.BikeRenderer;
import software.bernie.example.entity.BikeEntity;
import software.bernie.geckolib.GeckoLib;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.model.GeoModel;

/**
 * Example {@link GeoModel} for the {@link BikeEntity}
 * @see BikeRenderer
 */
public class BikeModel extends DefaultedEntityGeoModel<BikeEntity> {
	public BikeModel() {
		super(new Identifier(GeckoLib.MOD_ID, "bike"));
	}

	// We want this entity to have a translucent render
	@Override
	public RenderLayer getRenderType(BikeEntity animatable, Identifier texture) {
		return RenderLayer.getEntityTranslucent(getTextureResource(animatable));
	}
}
