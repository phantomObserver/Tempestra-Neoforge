package software.bernie.geckolib;

import java.io.Serial;
import net.minecraft.util.Identifier;

/**
 * Generic {@link Exception} wrapper for GeckoLib.<br>
 * Mostly just serves as a marker for internal error handling.
 */
public class GeckoLibException extends RuntimeException {
	@Serial
	private static final long serialVersionUID = 1L;

	public GeckoLibException(Identifier fileLocation, String message) {
		super(fileLocation + ": " + message);
	}

	public GeckoLibException(Identifier fileLocation, String message, Throwable cause) {
		super(fileLocation + ": " + message, cause);
	}
}
