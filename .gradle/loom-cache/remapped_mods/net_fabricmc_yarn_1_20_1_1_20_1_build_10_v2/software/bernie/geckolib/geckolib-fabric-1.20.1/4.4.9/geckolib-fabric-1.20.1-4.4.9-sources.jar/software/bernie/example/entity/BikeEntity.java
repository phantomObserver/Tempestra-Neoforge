package software.bernie.example.entity;

import software.bernie.example.client.renderer.entity.BikeRenderer;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.constant.DefaultAnimations;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Example {@link GeoAnimatable} implementation of an entity
 * @see BikeRenderer
 * @see software.bernie.example.client.model.entity.BikeModel
 */
public class BikeEntity extends AnimalEntity implements GeoEntity {
	private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

	public BikeEntity(EntityType<? extends AnimalEntity> type, World level) {
		super(type, level);

		this.ignoreCameraFrustum = true;
	}

	// Let the player ride the entity
	@Override
	public ActionResult interactMob(PlayerEntity player, Hand hand) {
		if (!this.hasPassengers()) {
			player.startRiding(this);

			return super.interactMob(player, hand);
		}

		return super.interactMob(player, hand);
	}

	// Turn off step sounds since it's a bike
	@Override
	protected void playStepSound(BlockPos pos, BlockState block) {}

	// Apply player-controlled movement
	@Override
	public void travel(Vec3d pos) {
		if (this.isAlive()) {
			if (this.hasPassengers()) {
				LivingEntity passenger = (LivingEntity)getControllingPassenger();
				this.prevYaw = getYaw();
				this.prevPitch = getPitch();

				setYaw(passenger.getYaw());
				setPitch(passenger.getPitch() * 0.5f);
				setRotation(getYaw(), getPitch());

				this.bodyYaw = this.getYaw();
				this.headYaw = this.bodyYaw;
				float x = passenger.sidewaysSpeed * 0.5F;
				float z = passenger.forwardSpeed;

				if (z <= 0)
					z *= 0.25f;

				this.setMovementSpeed(0.3f);
				super.travel(new Vec3d(x, pos.y, z));
			}
		}
	}

	// Get the controlling passenger
	@Nullable
	@Override
	public LivingEntity getControllingPassenger() {
		return getFirstPassenger() instanceof LivingEntity entity ? entity : null;
	}

	@Override
	public boolean isLogicalSideForUpdatingMovement() {
		return true;
	}

	// Add our generic idle animation controller
	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
		controllers.add(DefaultAnimations.genericIdleController(this));
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return this.cache;
	}

	@Override
	public PassiveEntity createChild(ServerWorld level, PassiveEntity partner) {
		return null;
	}
}
